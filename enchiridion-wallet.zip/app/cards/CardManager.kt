package com.walletnfc.cards

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.walletnfc.data.model.Card
import com.walletnfc.utils.EncryptionUtil

object CardManager {
    private const val PREF_NAME = "wallet_cards"
    private const val KEY_CARDS = "cards"

    fun saveCard(context: Context, card: Card) {
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val cards = getCards(context).toMutableList()

        cards.add(card)
        prefs.edit().putString(KEY_CARDS, Gson().toJson(cards)).apply()
    }

    fun getCards(context: Context): List<Card> {
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_CARDS, "[]")
        val array = Gson().fromJson(json, Array<Card>::class.java)
        return array.toList()
    }

    fun deleteCard(context: Context, id: String) {
        val cards = getCards(context).filterNot { it.id == id }
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_CARDS, Gson().toJson(cards)).apply()
    }
}