package com.walletnfc.data.model

data class Card(
    val id: String = "",
    val encryptedNumber: String = "",
    val holderName: String = "",
    val expiry: String = ""
)