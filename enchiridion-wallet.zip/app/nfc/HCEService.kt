package com.walletnfc.nfc

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import android.util.Log

class HCEService : HostApduService() {

    override fun onStartCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        Log.d("HCEService", "Received APDU: ${commandApdu?.decodeToString()}")

        val response = "9000" // SW_NO_ERROR - success status word
        return hexStringToByteArray(response)
    }

    override fun onDeactivated(reason: Int) {
        Log.d("HCEService", "Deactivated: $reason")
    }

    private fun hexStringToByteArray(data: String): ByteArray {
        val len = data.length
        val out = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            out[i / 2] = ((Character.digit(data[i], 16) shl 4)
                    + Character.digit(data[i + 1], 16)).toByte()
            i += 2
        }
        return out
    }
}