package com.walletnfc.ui.screens

import androidx.compose.foundation.lazy.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Transaction(val id: String, val date: String, val amount: String)

@Composable
fun TransactionHistoryScreen() {
    val transactions = listOf(
        Transaction("TXN1", "2025-03-20", "$12.99"),
        Transaction("TXN2", "2025-03-18", "$5.00"),
        Transaction("TXN3", "2025-03-15", "$99.00")
    )

    LazyColumn(modifier = Modifier.padding(16.dp)) {
        items(transactions) { txn ->
            Card(modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("ID: ${txn.id}")
                    Text("Date: ${txn.date}")
                    Text("Amount: ${txn.amount}")
                }
            }
        }
    }
}