package com.walletnfc.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.walletnfc.ui.screens.*

@Composable
fun WalletNavGraph(navController: NavHostController) {
    NavHost(navController, startDestination = "login") {
        composable("login") { LoginScreen(navController) }
        composable("signup") { SignupScreen(navController) }
        composable("dashboard") { DashboardScreen(navController) }
        composable("addCard") { AddCardScreen(navController) }
        composable("transactions") { TransactionHistoryScreen() }
        composable("tap") { TapToPayScreen(navController) }
    }
}