package com.walletnfc.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.walletnfc.cards.CardManager
import com.walletnfc.data.model.Card
import com.walletnfc.utils.EncryptionUtil
import java.util.*

@Composable
fun AddCardScreen(navController: NavController) {
    var number by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var expiry by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(Modifier.padding(16.dp)) {
        Text("Add New Card", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(value = number, onValueChange = { number = it }, label = { Text("Card Number") })
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Card Holder") })
        OutlinedTextField(value = expiry, onValueChange = { expiry = it }, label = { Text("Expiry (MM/YY)") })

        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            val encrypted = EncryptionUtil.encrypt(number)
            val card = Card(UUID.randomUUID().toString(), encrypted, name, expiry)
            CardManager.saveCard(context, card)
            navController.navigate("dashboard")
        }) {
            Text("Save Card")
        }
    }
}