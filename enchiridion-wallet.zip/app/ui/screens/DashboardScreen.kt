package com.walletnfc.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.walletnfc.auth.AuthManager

@Composable
fun DashboardScreen(navController: NavController) {
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text("Welcome to Your Wallet", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            navController.navigate("addCard")
        }) {
            Text("Add Card")
        }

        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            navController.navigate("transactions")
        }) {
            Text("Transaction History")
        }

        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            navController.navigate("tap")
        }) {
            Text("Tap to Pay")
        }

        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            AuthManager.signOut()
            navController.navigate("login")
        }) {
            Text("Logout")
        }
    }
}