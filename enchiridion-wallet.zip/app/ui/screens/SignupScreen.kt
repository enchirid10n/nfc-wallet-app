package com.walletnfc.ui.screens

@Composable
fun SignupScreen(navController: NavController) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Create Wallet Account", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") })
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            AuthManager.signUp(email, password, {
                navController.navigate("dashboard")
            }, { msg -> error = msg })
        }) {
            Text("Sign Up")
        }

        error?.let {
            Text(it, color = MaterialTheme.colors.error)
        }
    }
}