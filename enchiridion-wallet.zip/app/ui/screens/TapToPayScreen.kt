package com.walletnfc.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun TapToPayScreen(navController: NavController) {
    val context = LocalContext.current

    Column(Modifier.padding(16.dp)) {
        Text("Hold your device near terminal", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(32.dp))
        Button(onClick = {
            Toast.makeText(context, "NFC HCE activated - Tap simulation", Toast.LENGTH_SHORT).show()
        }) {
            Text("Simulate Tap-to-Pay")
        }

        Spacer(Modifier.height(16.dp))
        Button(onClick = { navController.navigate("dashboard") }) {
            Text("Back to Wallet")
        }
    }
}